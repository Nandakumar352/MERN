import React from 'react'

function Home () {
    return (
        <h1>Users Details</h1>
    )
}

export default Home